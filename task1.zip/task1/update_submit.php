
<?php
    include 'config.php'; 


    if(isset($_POST['submit'])){
        $id = $_POST['id'];
        $first_heading_banner = $_POST['first_heading_banner'];
        $first_sub_heading_banner = $_POST['first_sub_heading_banner'];
       

        $query = "UPDATE `banner_tbl` SET `first_heading`='".$first_heading_banner."',`first_sub_heading`='".$first_sub_heading_banner."' WHERE `id`='".$id."'";


        $run = mysqli_query($connection ,$query);
        header("location: http://localhost/company_project/task1/banner_tbl.php");
        

        }
?>