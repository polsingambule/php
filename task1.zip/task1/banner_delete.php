<?php 
	include 'config.php';

	$id = $_GET['id'];

	$deletequery = "DELETE FROM `banner_tbl` WHERE id = $id"; 

	$query = mysqli_query($connection , $deletequery);

	header("location: http://localhost/company_project/task1/banner_tbl.php");
?>