<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Otomanopee+One&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer"/>

  <link rel="stylesheet" href="css/admin.css">
  <link rel = "icon" href ="images/X_logo.png" type = "Images/x-icon">
  <title>Admin Panel</title>
</head>
<body>
  <section id="admin_panel">
    <div class="admin_content_main">
      <div class="admin_content_col admin_content_col_1">
        <h3>Wellcome Admin</h3>
        <div class="admin_content">
            <a href="#"><p>Home Page</p></a>
              <a href="http://localhost/company_project/task1/banner.php"><span>Banner Section</span></a>
              <a href="http://localhost/company_project/task1/banner_tbl.php"><ins>Banner Table</ins></a>
              <a href="http://localhost/company_project/task1/sevices.php"><span>Sevices Section</span></a> 
              <a href="http://localhost/company_project/task1/testimonials.php"><span>Testimonials Section</span></a>
              <a href="http://localhost/company_project/task1/recent_news.php"><span class="active">Recent News Section</span></a>
        </div>
        <div class="admin_content">
            <a href="#"><p>About Us</p></a>
              <a href="#"><span>-----</span></a>
              <a href="#"><span>-----</span></a> 
              <a href="#"><span>-----</span></a>
              <a href="#"><span>-----</span></a>
        </div>
        <div class="admin_content">
            <a href="#"><p>Gallery</p></a>
              <a href="#"><span>-----</span></a>
              <a href="#"><span>-----</span></a> 
              <a href="#"><span>-----</span></a>
              <a href="#"><span>-----</span></a>
        </div>
        <div class="admin_content">
          <a href="#"><p>Products</p></a>
            <a href="#"><span>-----</span></a>
            <a href="#"><span>-----</span></a> 
            <a href="#"><span>-----</span></a>
            <a href="#"><span>-----</span></a>
        </div>
        <div class="admin_content">
          <a href="#"><p>Contact Us</p></a>
            <a href="#"><span>-----</span></a>
            <a href="#"><span>-----</span></a> 
            <a href="#"><span>-----</span></a>
            <a href="#"><span>-----</span></a>  
        </div>
      </div>
      <div class="admin_content_col admin_content_col_2">
        <div class="tbl_heading">
          <h3>Banner Section Table</h3>
        </div>
        <table>
          <tr>
            <th style="text-align: center;">Id</th>
            <th style="width:200px;">First Heading</th>
            <th>First Sub Heading</th>
            <th colspan="2" style="text-align: center;">Operators</th>
          </tr>
           <?php

            include 'config.php';

            $selectquery = "SELECT * FROM `banner_tbl`";

            $query = mysqli_query($connection, $selectquery);
            $i=1;

            while($result = mysqli_fetch_assoc($query)){
          ?>

          <tr> 
            <td style="text-align: center;"><?php echo $i; ?></td>
            <td><?php echo $result['first_heading']; ?></td>
            <td><?php echo $result['first_sub_heading']; ?></td>
            <td class="editBtn" style="text-align: center;"><a href="banner_edit.php?id=<?php echo $result['id']; ?>"><i class="fa-regular fa-pen-to-square"></i></a></td>
            <td class="deleteBtn" style="text-align: center;"><a href="banner_delete.php?id=<?php echo $result['id']; ?>"><i class="fa-solid fa-trash"></i></a></td>
             </tr>
            <?php 
             $i++; }
            ?>
          </table>
      </div>
    </div>
  </section>
</body>
</html>