<?php 
	$servername = "localhost";
	$userName = "root";
	$password = ""; 
	$db_name = "company";  



	$connection = mysqli_connect($servername,$userName,$password,$db_name);
?>
