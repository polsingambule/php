<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Otomanopee+One&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/admin.css">
  <link rel = "icon" href ="images/X_logo.png" type = "Images/x-icon">
  <title>Admin Panel</title>
</head>
<body>
  <section id="admin_panel">
    <div class="admin_content_main">
      <div class="admin_content_col admin_content_col_1">
        <h3>Wellcome Admin</h3>
        <div class="admin_content">
            <a href="#"><p>Home Page</p></a>
              <a href="http://localhost/company_project/task1/banner.php"><span>Banner Section</span></a>
              <a href="http://localhost/company_project/task1/sevices.php"><span class="active">Sevices Section</span></a> 
              <a href="http://localhost/company_project/task1/testimonials.php"><span>Testimonials Section</span></a>
              <a href="http://localhost/company_project/task1/recent_news.php"><span>Recent News Section</span></a>
        </div>
        <div class="admin_content">
            <a href="#"><p>About Us</p></a>
              <a href="#"><span>-----</span></a>
              <a href="#"><span>-----</span></a> 
              <a href="#"><span>-----</span></a>
              <a href="#"><span>-----</span></a>
        </div>
        <div class="admin_content">
            <a href="#"><p>Gallery</p></a>
              <a href="#"><span>-----</span></a>
              <a href="#"><span>-----</span></a> 
              <a href="#"><span>-----</span></a>
              <a href="#"><span>-----</span></a>
        </div>
        <div class="admin_content">
          <a href="#"><p>Products</p></a>
            <a href="#"><span>-----</span></a>
            <a href="#"><span>-----</span></a> 
            <a href="#"><span>-----</span></a>
            <a href="#"><span>-----</span></a>
        </div>
        <div class="admin_content">
          <a href="#"><p>Contact Us</p></a>
            <a href="#"><span>-----</span></a>
            <a href="#"><span>-----</span></a> 
            <a href="#"><span>-----</span></a>
            <a href="#"><span>-----</span></a> 
        </div>
      </div>
      <div class="admin_content_col admin_content_col_2">
        <form action="config.php" method="POST">
          <h2><span class="circle">&#128308;</span> Banner Section</h2>
          <h3>First Heading</h3>
          <input class="admin_inputs admin_input" type="text" name="first_heading_banner" required placeholder="First Heading"><br>
          <h3>First Sub Heading</h3>
          <textarea rows="4" class="admin_inputs admin_textarea" name="first_sub_heading_banner" required placeholder="First Sub Heading"></textarea>
          <br><br>
          <div class="chenge_admin_btn">
            <button type="submit" name="submit_banner">Save Chenge</button>
          </div>
        </form>
      </div>
    </div>
  </section>
</body>
</html>