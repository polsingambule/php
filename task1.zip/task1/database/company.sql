-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2022 at 03:04 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `company`
--

-- --------------------------------------------------------

--
-- Table structure for table `banner_tbl`
--

CREATE TABLE `banner_tbl` (
  `id` int(255) NOT NULL,
  `first_heading` varchar(1000) NOT NULL,
  `first_sub_heading` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banner_tbl`
--

INSERT INTO `banner_tbl` (`id`, `first_heading`, `first_sub_heading`) VALUES
(33, 'Heading Here', 'Lorem Ipsum Dolor Sit Amet, Consectetur Adipisicing Elit. Incidunt Quis, Architecto Quasi. Iste Excepturi Veniam Ea Maxime Libero Officia, Nesciunt.');

-- --------------------------------------------------------

--
-- Table structure for table `recent_news_tbl`
--

CREATE TABLE `recent_news_tbl` (
  `first_heading` varchar(255) NOT NULL,
  `first_date` varchar(255) NOT NULL,
  `first_paragrap` varchar(255) NOT NULL,
  `second_heading` varchar(255) NOT NULL,
  `second_date` varchar(255) NOT NULL,
  `second_paragrap` varchar(255) NOT NULL,
  `third_heading` varchar(255) NOT NULL,
  `third_date` varchar(255) NOT NULL,
  `third_paragrap` varchar(255) NOT NULL,
  `fourth_heading` varchar(255) NOT NULL,
  `fourth_date` varchar(255) NOT NULL,
  `fourth_paragrap` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `services_tbl`
--

CREATE TABLE `services_tbl` (
  `first_heading` int(255) NOT NULL,
  `first_paragrap` int(255) NOT NULL,
  `second_heading` int(255) NOT NULL,
  `second_paragrap` int(255) NOT NULL,
  `third_heading` int(255) NOT NULL,
  `third_paragrap` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `testimonials_tbl`
--

CREATE TABLE `testimonials_tbl` (
  `first_paragrap` varchar(255) NOT NULL,
  `second_paragrap` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banner_tbl`
--
ALTER TABLE `banner_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banner_tbl`
--
ALTER TABLE `banner_tbl`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
